package com.beautyapp.beauty_product_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.beautyapp.beauty_product_system.entity.BeautyProduct;

public interface BeautyProductRepository
        extends JpaRepository<BeautyProduct, Long> {
}