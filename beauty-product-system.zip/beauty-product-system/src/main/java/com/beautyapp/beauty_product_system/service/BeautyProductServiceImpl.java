package com.beautyapp.beauty_product_system.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beautyapp.beauty_product_system.entity.BeautyProduct;
import com.beautyapp.beauty_product_system.repository.BeautyProductRepository;

@Service
public class BeautyProductServiceImpl implements BeautyProductService {

    @Autowired
    private BeautyProductRepository repository;
    
    @Override
    public List<BeautyProduct> saveAllProducts(List<BeautyProduct> products) {
    	return repository.saveAll(products);
    }

    @Override
    public BeautyProduct saveProduct(BeautyProduct product) {
        return repository.save(product);
    }

    @Override
    public List<BeautyProduct> getAllProducts() {
        return repository.findAll();
    }

    @Override
    public BeautyProduct getProductById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Product not found with id: " + id));
    }

    @Override
    public BeautyProduct updateProduct(Long id, BeautyProduct product) {
        BeautyProduct existing = getProductById(id);

        existing.setName(product.getName());
        existing.setBrand(product.getBrand());
        existing.setCategory(product.getCategory());
        existing.setPrice(product.getPrice());

        return repository.save(existing);
    }

    @Override
    public void deleteProduct(Long id) {
        repository.deleteById(id);
    }
}