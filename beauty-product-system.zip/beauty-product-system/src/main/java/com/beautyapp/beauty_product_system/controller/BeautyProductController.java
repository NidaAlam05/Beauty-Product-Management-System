package com.beautyapp.beauty_product_system.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.beautyapp.beauty_product_system.entity.BeautyProduct;
import com.beautyapp.beauty_product_system.service.BeautyProductService;

@RestController
@RequestMapping("/api/products")
public class BeautyProductController {

    @Autowired
    private BeautyProductService service;

    // ✅ TEST API
    @GetMapping("/test")
    public String test() {
        return " BEAUTY PRODUCT API IS WORKING-By NIDA.";
    }

    // ✅ ADD PRODUCT
    @PostMapping
    public ResponseEntity<BeautyProduct> addProduct(
            @Valid @RequestBody BeautyProduct product) {

        return new ResponseEntity<>(
                service.saveProduct(product),
                HttpStatus.CREATED
        );
    }
    
    @PostMapping("/bulk")
    public ResponseEntity<List<BeautyProduct>> addBulkProducts(
            @Valid @RequestBody List<BeautyProduct> products) {

        List<BeautyProduct> savedProducts = service.saveAllProducts(products);
        return new ResponseEntity<>(savedProducts, HttpStatus.CREATED);
    }

    // ✅ GET ALL
    @GetMapping
    public List<BeautyProduct> getAllProducts() {
        return service.getAllProducts();
    }

    // ✅ GET BY ID
    @GetMapping("/{id}")
    public BeautyProduct getById(@PathVariable Long id) {
        return service.getProductById(id);
    }

    // ✅ UPDATE
    @PutMapping("/{id}")
    public BeautyProduct update(
            @PathVariable Long id,
            @Valid @RequestBody BeautyProduct product) {

        return service.updateProduct(id, product);
    }

    // ✅ DELETE
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteProduct(id);
        return "Product deleted successfully";
    }
}