package com.beautyapp.beauty_product_system.service;

import java.util.List;

import com.beautyapp.beauty_product_system.entity.BeautyProduct;

import jakarta.validation.Valid;

public interface BeautyProductService {

    BeautyProduct saveProduct(BeautyProduct product);

    List<BeautyProduct> getAllProducts();

    BeautyProduct getProductById(Long id);

    BeautyProduct updateProduct(Long id, BeautyProduct product);

    void deleteProduct(Long id);

	List<BeautyProduct> saveAllProducts(@Valid List<BeautyProduct> products);

    
}