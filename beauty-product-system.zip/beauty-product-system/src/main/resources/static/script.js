const API_URL = "http://localhost:9090/api/products";

function addProduct() {
    const product = {
        name: document.getElementById("name").value,
        brand: document.getElementById("brand").value,
        category: document.getElementById("category").value,
        price: document.getElementById("price").value
    };

    fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(product)
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById("msg").innerText = "Product Added Successfully 💖";
        getProducts();
    })
    .catch(err => alert("Error adding product"));
}

function getProducts() {
    fetch(API_URL)
    .then(res => res.json())
    .then(data => {
        const list = document.getElementById("productList");
        list.innerHTML = "";

        data.forEach(p => {
            list.innerHTML += `
                <div class="product">
                    <b>${p.name}</b><br>
                    Brand: ${p.brand}<br>
                    Category: ${p.category}<br>
                    Price: ₹${p.price}
                </div>
            `;
        });
    });
}